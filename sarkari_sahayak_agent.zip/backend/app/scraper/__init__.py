"""Scraper package initialization."""
