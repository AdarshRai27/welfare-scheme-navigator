"""Prompt templates subpackage initialization."""
